const DEV_MODE = false; // Development flag - set to false for production

function cambiarFondo() {
    const ahora = new Date();
    let hora = ahora.getHours();
    console.log('Hora actual:', hora);

    if (DEV_MODE) {
        const horaTest = prompt("¿Hora? (6-23)");
        if (horaTest !== null) {
            hora = parseInt(horaTest);
            console.log('Hora de prueba:', hora);
        }
    }

    let colorFondo;
    let mensaje;

    if (hora >= 6 && hora < 12) {
        colorFondo = "#FFEEA9"; // Amarillo claro
        mensaje = "Buenos días ☀️";
        document.body.style.color = "black";
    } else if (hora >= 12 && hora < 18) {
        colorFondo = "#FFB74D"; // Naranja claro
        mensaje = "Buenas tardes 🌇";
        document.body.style.color = "black";
    } else {
        colorFondo = "#2C3E50"; // Azul oscuro
        mensaje = "Buenas noches 🌙";
        document.body.style.color = "white";
    }

    document.body.style.backgroundColor = colorFondo;
    document.getElementById("mensaje").innerText = mensaje;
}

cambiarFondo(); // Cambia el fondo al cargar la página
setInterval(cambiarFondo, 60000); // Actualiza cada minuto