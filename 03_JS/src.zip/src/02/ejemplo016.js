for (let i=1; i<=10; i++){
    console.log(i);
}

let suma = 0;
for (let i=1; i<=10; i++){
    suma = suma + i;
}
console.log(suma);


// Tabla multiplicar
let tabladel = 7
for (let i=1; i<=10; i++){
    let res = tabladel * i;
    console.log(tabladel, " x ", i, " = ", res)
}