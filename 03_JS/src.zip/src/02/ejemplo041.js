
function media(lista) {
    let suma = 0;
    for (const element of lista) {
        suma += element  
    }
    return suma/lista.length;
}

let edades_A = [23, 34, 45, 19, 25, 31];
let edades_B = [45, 51, 37, 28, 18];

let medA = media(edades_A);
let medB = media(edades_B);

console.log(medA, medB)
if (medA>medB) 
    console.log("A > B");
else if (medA<medB) 
    console.log("A < B");
else
    console.log("A = B");

// console.log(media([]))