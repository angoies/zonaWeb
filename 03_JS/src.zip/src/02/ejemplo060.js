
// ejemplo de funciones de retorno que recieb
// o, 1, 2 o tres parámetros

//ninguno
function fcallback0() {
  document.write("<br>llamada a callback0");
}

let numeros = [4, 9, 16, 25];
numeros.forEach(fcallback0);

// uno, por ser el 1ª el elemento
function fcallback1(ele) {
  document.write("<br>llamada a callback1: ", ele);
}
numeros.forEach(fcallback1);

// dos, el elemento y su índice
function fcallback2(ele, indice) {
  document.write("<br>llamada a callback2: ", "x[", indice, "]=", ele);
}
numeros.forEach(fcallback2);

// ttes, el elemento, su índice y array completo
function fcallback3(ele, indice, array) {
  document.write(
    "<br>llamada a  callback3 ",
    "x[", indice,"]=", ele, 
    " - Array completo: ", array
  );
}
numeros.forEach(fcallback3);


let alumnos = [ 
  {nombre: "Ana Tendero", edad: 27 },
  {nombre: "Luis Fornes", edad: 19 },
  {nombre: "Bet Villa", edad: 21 }
];

function muestraAlu(ele, index) {
  let texto = "<br> pos " + index + " > " +
       ele.nombre + " " + ele.edad;
  document.write(texto);
}

alumnos.forEach(muestraAlu);

// every  y some

// función de comprobación
function compruebaAdulto(edad) {
  return edad >= 18; // DEVUELVE true o false
}

let edades = [32, 33, 16, 40];
document.write("<br> Edades: ", edades);
let todos_adultos = edades.every(compruebaAdulto);
document.write("<br>Todos adultos: ", todos_adultos);
let algun_adulto = edades.some(compruebaAdulto);
document.write("<br>Algún Adulto: ", algun_adulto);

// map
let valores= [1, 4, 9];
console.log("Valores: ", valores)

let raices = valores.map(Math.sqrt);
console.log("Raices: ", raices)
// raices [1, 2, 3]

// usando función definida
function duplica(a) {
    return a*2;
}
let dobles  = valores.map(duplica);   
console.log("dobles: ", dobles)
// dobles [2, 8, 18]

// usando función anónima
dobles  = valores.map( function(num) {
  return num * 2;
});   
console.log("dobles: ", dobles)
// dobles [2, 8, 18]

// usnado notación "arrow"
dobles  = valores.map( a => a*2);  
console.log("dobles: ", dobles)

// Ejemplo de proceso que usa el índice...
function procesa (valor, index) {
  return valor * (index+1);
}
let procesados= valores.map(procesa);
console.log("procesados: ", procesados)
// procesados [1, 8, 27] 


// filter
edades = [32, 33, 16, 40];
console.log("edades: ", edades)
function esAdulto(edad) {
   return (edad >= 18); // debe devolver true|false
}
let adultos = edades.filter(esAdulto);
console.log("adultos: ", adultos)
// función flecha, nueva sintaxis en ES6
let menores = edades.filter( a => a<18 );
console.log("menores: ", menores)
