let marcas = ["Volvo", "Toyota", "Seat" ];
let temperaturas = [12.5, 13.6, 8.0, 19.2, 23.4];

console.log(marcas.length);

console.log(marcas[0])

console.log(marcas[1])
marcas[1] = "Renault";
console.log(marcas[1])

// Bucle usando variable de control
for (let i = 0; i < temperaturas.length; i++) {
    console.log(i, " - ", temperaturas[i]);
}

let media = 0;
let suma = 0;

// Versión clásica
// for (let i = 0; i < temperaturas.length; i++) {
//     suma += temperaturas[i];
// }

// Versión actual si no necesita la variable de control
for (const element of temperaturas) {
    suma += element;
}

media = suma/temperaturas.length;
console.log("Media: ", media)