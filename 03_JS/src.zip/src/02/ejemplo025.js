let nombre ="Ana";
let apellido = "Herrera";

console.log(nombre[0]);
console.log(nombre.length);

// otra forma: let nombreCompleto = apellido + ", " + nombre;
let nombreCompleto = apellido.concat(", ", nombre);
console.log(nombreCompleto);


// Observe que toUpperCase no modifica la cadena
console.log("nombre:", nombre.toUpperCase());
console.log("nombre:", nombre)

// Si desea modificarla
nombre = nombre.toUpperCase();
console.log("nombre:", nombre)

// buscar un carácter
let pos = nombreCompleto.indexOf("H");
console.log("H en posición ", pos);

// replace no modifica cadena original
let empresas = "Google,Oracle,IBM"
console.log(empresas.replace("Oracle", "Microsoft"))
console.log(empresas);

// uso de split: empresas es cadena, lista es array
let lista = empresas.split(",");
console.log("empresas: ", empresas);
console.log("  longitud: ", empresas.length);
console.log("lista: ", lista);
console.log("  longitud: ", lista.length);