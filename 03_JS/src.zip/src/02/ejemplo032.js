let fruits = ["Apple", "Orange", "Apple", "Mango"];
let position = fruits.indexOf("Apple");
console.log("busco Apple desde inicio: ", position);

position = fruits.lastIndexOf("Apple");
console.log("busco Apple desde final: ", position);

let encontrado = fruits.includes("Mango"); // is true 
console.log("mango está incluido: ", encontrado);
encontrado = fruits.includes("kiwi"); // is true 
console.log("kiwi está incluido: ", encontrado);