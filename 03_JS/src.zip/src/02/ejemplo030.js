// longitud o tamaño del array
let fruits = ["Banana", "Orange", "Apple", "Mango"];
let size = fruits.length;

// concat
const myGirls = ["Cecilie", "Lone"];
const myBoys = ["Emil", "Tobias", "Linus"];

const myChildren = myGirls.concat(myBoys);


// join 
fruits = ["Banana", "Orange", "Apple", "Mango"];
let texto = fruits.join(" - ")
console.log(fruits);
console.log(texto);


// The pop() method removes the last element from an array:
fruits = ["Banana", "Orange", "Apple", "Mango"];
console.log(fruits);
let res = fruits.pop();
console.log(fruits);
console.log(res)

// The push() method adds a new element to an array (at the end):
fruits = ["Banana", "Orange", "Apple", "Mango"];
size = fruits.push("Kiwi");
console.log(fruits);
console.log(size)

// The shift() method removes the first array element and "shifts" all other elements to a lower index.
// The unshift() method adds a new element to an array (at the beginning), and "unshifts" older elements: 

// The reverse() method reverses the elements in an array:
fruits = ["Banana", "Orange", "Apple", "Mango"];
console.log(fruits);
console.log(fruits.reverse());
console.log(fruits);

// slice
fruits = ["Banana", "Orange", "Lemon", "Apple", "Mango"];
console.log(fruits);
let citrus = fruits.slice(1, 3);
console.log(fruits);
console.log(citrus);

// splice
// uso 1: insertar (no se borra nada)
console.log("splice 1")
fruits = ["Banana", "Orange", "Apple", "Mango"];
console.log(fruits);
fruits.splice(2, 0, "Lemon", "Kiwi");
console.log(fruits);
// uso 2: borrar
console.log("splice 2")
fruits = ["Banana", "Orange", "Apple", "Mango"];
console.log(fruits);
let borrados = fruits.splice(0, 1);
console.log(fruits);
console.log(borrados);
