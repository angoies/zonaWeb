let alumno = {
  nombre: "Ana",
  apellidos: "Milton",
  id: 5566,
};

console.log(alumno.nombre); // 1)
console.log(alumno["nombre"]); // 2)

for (let prop in alumno) {
  console.log(prop + ":", alumno[prop]);
}

let alumnos = [
  { nombre: "Ana Tendero", edad: 27 },
  { nombre: "Luis Fornes", edad: 16 },
  { nombre: "Bet Villa", edad: 21 },
];

function media(alumnos) {
  let suma = 0;
  for (const element of alumnos) {
    suma += element.edad;
  }
  return suma / alumnos.length;
}
document.write("<br>Media: ", media(alumnos));

 // definición de objeto con método
let person = {   
    firstName: "John",
    lastName : "Doe",
    id       : 5566,
    fullName : function() {   // uso de this
       return this.firstName + " " +           
              this.lastName;
    }
};

// invocación 
console.log( person.fullName() );


// Otro ejemplo: se define objeto y luego
//  se añaden propiedades y métodos

let estudiante = {}; // se define objeto 
estudiante.id = "ASIR-1-001";
// algunas propiedades son arrays
estudiante.modulos = ["LMSGI", "PAR", "FOL", "ISO"];
estudiante.notas = [4, 6, 9, 2];
// se añade método
estudiante.media = function () {
 let suma = 0;
 for (const element of this.notas)
   suma += element;
 return suma/this.notas.length;
}

// accedemos a las propiedades
console.log(estudiante.id);
for (let i = 0; i < estudiante.modulos.length; i++)
  console.log(estudiante.modulos[i], ":", estudiante.notas[i]);

//invocación del método
console.log("Media:", estudiante.media());