// Definición función 
function linea () {
    for (let i=0; i < 80; i++)
        document.write('*');
    document.write("<br/>");
 } 
//  Invocación  función
 linea();
 document.write("Hola Mundo! <br>");
 linea();

// función con un parámetro
function linea01 (tam) {
    for (let i=0; i < tam; i++)
        document.write('*');
    document.write("<br/>");
} 

linea01(5);
linea01(40);

// función con dos parámetros
function linea02 (tam, letra) {
    for (let i=0; i < tam; i++)
        document.write(letra);
    document.write("<br/>");
} 

linea02(5, "#");
linea02(40, "=");
let longitud = prompt("Tamaño");
let car = prompt("carácter: ");
linea02(longitud, car);


// función que usa otra función 
// pirámide 

function piramide(altura) {
    for (let i = 1; i <= altura; i++) {
        linea02(i, "*");
    }
}
let altura = prompt("Altura: ");
piramide(altura)