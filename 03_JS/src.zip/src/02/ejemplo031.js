// The sort() method sorts an array alphabetically: LO MODIFICA
const fruits = ["Banana", "Orange", "Apple", "Mango"];
console.log(fruits);
fruits.sort();
console.log(fruits);
// descendente: reverse
fruits.reverse();
console.log(fruits);


// ordenar números: ahce falta función d compración 
function compara(a, b){
    return a - b;
}
let points = [40, 100, 1, 5, 25, 10];
console.log(points);
points.sort(compara);
console.log(points);

// con función anónima
points = [40, 100, 1, 5, 25, 10];
console.log(points);
points.sort( function (a, b){return a - b;} );
console.log(points);

// con notación arrow
points = [40, 100, 1, 5, 25, 10];
console.log(points);
points.sort( (a, b) => a - b);
console.log(points);