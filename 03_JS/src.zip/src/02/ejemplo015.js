let edad = Number(prompt("Edad: "));

if (edad == null || edad < 18) {
    alert("Menor de edad");
}
else {
    alert("Mayor de edad"); 
}


let nota = Number(prompt("Nota: "));

if (nota < 5) {
    alert("Suspendo");
} else if (nota < 6) {
    alert("Aprobado"); 
} else if (nota < 9 ) {
    alert("Notable"); 
} else if (nota <= 10) {
    alert("Sobresaliente"); 
} else
  alert("Nota fuera de rango"); 