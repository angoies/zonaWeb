let enlaces = document.getElementsByTagName("a");
alert("Numero de enlaces total:  " + enlaces.length);

let cont = 0; // enlaces a Google
for (let i = 0; i < enlaces.length; i++) {
  url = enlaces[i].href;
  if (url.startsWith("http://www.google.com/"))
    cont++;
}
alert("Numero de enlaces a Google: " + cont);
