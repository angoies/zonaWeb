let num1 = prompt("num1: ");
let num2 = prompt("num2: ");

let coc = num1/num2;

if (isNaN(coc) == true) {
    console.log("División no definida");
} else {
    console.log("Div es igual a: " + coc);
}

num1 = 4564.34567;
console.log(num1);
console.log(num1.toFixed(2)); // 4564.35
console.log(num1);