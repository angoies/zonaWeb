console.log(Math.sqrt(14));
let media = 5.6;
let m = Math.floor(media);
console.log(m);
m = Math.round(media);
console.log(m);


// Math.random()` devuelve un número aleatorio entre 0 y 1 (sin incluir el 1).Si desea un nº aleatorio entre 1 y 10
// random devuelve entre 0 y 1 con decimales..
//  y necesitaremos floor para redondear a nº entero,
let aleat = Math.floor( (Math.random()*10) + 1 );
console.log("aleat:", aleat)

/* aleatorio entre variables min y max  */ 
let max = 100;
let min = 1;
aleat = Math.floor(Math.random()*(max - min + 1)) + min; 
console.log("aleat:", aleat)

// Puede crear una función para encapsular el cálculo:
function getRndInteger(min, max) {
  return Math.floor(Math.random()*(max - min + 1)) + min;
}
aleat = getRndInteger(1,100);
console.log("aleat:", aleat)
