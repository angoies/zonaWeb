// File: dom-004.js

function test() {

    let titulos = document.querySelectorAll("[title]");

    // acceso al valor de un atributo
    for (const element of titulos) {
        let texto = element.getAttribute("title");
        console.log("Elemento: ", element);
        console.log("Title: ", texto);
    }

    let h1 = document.querySelector("h1");
    h1.setAttribute("title", "título generado desde script");



    // Caso espcial: con tributo href: se obtiene  
    //  * al usar el método: el valor del atributo
    //  * al suar la propiedad: la URL absoluta
    let enlaces = document.querySelectorAll("nav a");
    for (const element of enlaces) {
        console.log("con href: ", element.href);
        console.log("con getAttribute: ", element.getAttribute("href"));
    }


// Trabajando con clases (atributo class)
//   * `classList.add(clase)`
//   * `classList.remove(clase)`
//   * `classList.contains(clase)`
//   * `classList.toggle(clase)`

    let h2 = document.querySelector("section h2");
    console.log("h2.className: ", h2.className);
    h2.classList.add("nueva");
    console.log("h2.className (tras añadir nueva): ", h2.className);

    let p = document.querySelector("section p.novedad");
    console.log("p.className: ", p.className);
    p.classList.remove("danger");
    console.log("p.className (tras eliminar danger): ", p.className);


}