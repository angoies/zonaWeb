// File: dom-003.js

// Ejemplos de .querySelector() y .querySelectorAll()
//    .querySelector => el primero que cumpla, SOLO UNO
//    .querySelectorAll => todos los que cumplan => LISTA

function test() {
  let primero = document.querySelector("p");
  primero.style.textDecoration = "underline green 4px solid";

  let parrafos = document.querySelectorAll("section p:nth-of-type(odd)");
  // Clásica al revés: for (let i = parrafos.length - 1; i >= 0; i--) {
  //   parrafos[i].style.color = "red";
  // }
  for (const element of parrafos) {
    element.style.color = "red";
  }
}
