// File: dom-002.js

// función asociada al evento click de un botón en HTML
function test() {

  // uso de .getElementsByTagName()
  // ejemplo acceso por etiqueta, devuelve colección de elementos
  let parrafos = document.getElementsByTagName("p");

  // mostramos párrafos en consola en orden inverso 
  // .innerHTML => ver como los párrafos llevan el HTML "interno"
  // .textContent => no contiene el HTML "interno"
  for (let i = parrafos.length - 1; i >= 0; i--) {
    console.log(parrafos[i].innerHTML);
    console.log(parrafos[i].textContent);
  }

  //si el orden no es importante usar for-of
  console.log(">>> párrafos recorridos con for-of")
  for (const element of parrafos) {
    console.log(element.textContent);
  }

  // Ejemplo diferencias uso .textContent vs .innerHTML
  // contar nº de letras de todos los párrafos:
  // usamos textContent para no contar tags HTML..

  let suma = 0;
  for (const element of parrafos) {
    suma = suma + element.textContent.length
  }
  console.log("Total chars en párrafos: ", suma);

  // .getElementById()
  //    acceso por ID: deb devolver un único elemento
  alert("busca elemento con id='content' y le aplica border doble");
  let contenido = document.getElementById("content");
  contenido.style.border = "4px blue double";
}