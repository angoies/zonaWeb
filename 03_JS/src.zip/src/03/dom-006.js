// File: dom-005.js

function test() {

    // Creación de elementos
    //  * se crea
    //  * se define contenidos
    //  * se definen estilos
    //  * se inserta
    //     * antes o después (before/after)
    //     * el primer o último hijo (prepend/append)

    // ejemplo antes/después
    let nuevo = document.createElement("h2");
    nuevo.textContent = "Cabecera creada desde JS";
    nuevo.style.color = "red"

    let h1 = document.querySelector("h1");
    h1.after(nuevo);

    // ejemplo primero/últmo de un contenedor
    let padre = document.querySelector("nav ol");
    nuevo = document.createElement("li");
    nuevo.innerHTML="<a href='test'> Enlace generado desde script </a>";
    nuevo.style.fontWeight = "bold";
    padre.prepend(nuevo);

    // ejemplo de borrado
    let p = document.querySelector("h2+p");
    p.remove();

}