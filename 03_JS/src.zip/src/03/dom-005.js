// File: dom-005.js

function test() {

    // se modifica estilos de un elemento
    let h1 = document.querySelector("h1");
    h1.style.backgroundColor = "yellow";
    h1.style.textDecoration = "underline red 4px double";

    // modificación de estilos indirecta
    //   se añade una clase que tiene estilos CSS
    let h2 = document.querySelector("section h2");
    h2.classList.add("destacar");

    // se modifican estilos de una LISTA de elementos
    let enlaces = document.querySelectorAll("nav a");
    for (const element of enlaces) {
        element.style.textTransform = "uppercase";
        element.style.fontWeight = "bold";
    }
}