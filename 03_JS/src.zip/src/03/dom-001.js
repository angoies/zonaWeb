// file: dom-001.js

// accede a propiedades de document
let titulo = document.title;
let url = document.URL;
let lastModified = document.lastModified;

console.log("Títle: ", titulo);
console.log("URL: ", url);
console.log("Modificado: ", lastModified);

// accede a los enlaces: document.links es un  HTMLCollection 
console.log(document.links);

// forma "clásica" de recorrer
for (let i = 0; i < document.links.length; i++)
    console.log(document.links[i]);

// forma actual
for (const element of document.links)
    console.log(element);

