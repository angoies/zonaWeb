// File: dom-005.js

function verHora() {
  let demo = document.getElementById("demo");
  demo.innerHTML = Date();
}

let btn03 = document.getElementById("ver03")
btn03.onclick = verHora;

let btn04 = document.getElementById('ver04');
btn04.addEventListener("click", verHora)

// Ejemplo validación  formularios
function checkForm() {
  let pwd1 = document.getElementById("pwd1");
  let pwd2 = document.getElementById("pwd2");
  if (pwd1.value != pwd2.value) {
    alert("Error: clave y confirmación deben ser iguales");
    return false; //si onsubmit devuelve false no se envía formulario
  }
  return true;
}



// Ejemplo de asociar evento a una lista de elementos

// en la función que maneja el evento se usa el objeto this
//  que referencia al elemento que invoca la función
function decora() {
  console.log(this)
  this.style.color = "red";
}

let parrafos = document.querySelectorAll("section p");
for (const element of parrafos) {
  element.onclick=decora;
}

