let edadA = 27;
let edadB = 32;
let media = 0;

let suma = edadA + edadB;
media = suma/2;
console.log("Media:", media)

let edadC = 19;
suma = suma + edadC;
// notación compacta: suma += edadC;
media = suma/3;
console.log("Media:", media)



