/* 
  Comentario de nloque 
*/
alert("Hola desde script en fichero invocado en body de fichero HTML")