function sumar() {
    let sumandoA = document.getElementById("a").value;
    // truco para accder directamente a elemento por su id
    let sumandoB = b.value;
    res.innerHTML = Number(sumandoA) + Number(sumandoB);  
    // truco para lo mismo
    // res.innerHTML = sumandoA*1 + sumandoB*1
}

