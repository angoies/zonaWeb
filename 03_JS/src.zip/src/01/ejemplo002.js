function avisar(texto) {
    alert("texto")  // comentario "de línea"
}
