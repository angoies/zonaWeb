
let seguir = confirm("¿Desea sumar dos números?")

// versión "extendida"  // if (seguir == true) {
if (seguir) { // versión abreviada
    let a = prompt("a: ");
    let b = prompt("b: ");
    if (a!= null && b!=null){
        // Ejercicio: RESOLVER ERROR en la suma
        let res = a + b;
        alert("Suma: " + res);
    } else
        alert("Pulso Cancelar en alguno de los números")
} else
    alert("No quiere sumar números")

