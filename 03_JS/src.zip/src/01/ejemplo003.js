// Numbers:
let length = 16;
let weight = 7.5;

console.log(typeof(weight))
console.log(typeof(length))

// ojo a la n final => bigint
let enteroEnorme = 123456789123456789123n;
console.log(typeof enteroEnorme, ": ", enteroEnorme)
// sin n, error de precisión...
let enteroError =  123456789123456789123;
console.log(typeof enteroError, ": ", enteroError)

// Strings:
let color = "Yellow";
let lastName = "Johnson";
console.log(typeof(lastName))

// Booleans
let x = true;
let y = false;
console.log(typeof(x))

// undefined
let z;
console.log("z: ", z)
console.log(typeof z)

// null
let w = null;
console.log("w: ", w)
console.log(typeof w) // object ¿bug?

// Object:
const person = {firstName:"John", lastName:"Doe"};
console.log(typeof(person))

// Array object:
const cars = ["Saab", "Volvo", "BMW"];
console.log(typeof(cars))
console.log("Es array: ", Array.isArray(cars))

// Date object:
const date = new Date("2022-03-25");
console.log(typeof(date))
console.log("es Date: ", date instanceof Date)