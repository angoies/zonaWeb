// api.js
async function obtenerClima() {
    // Puedes cambiar la ciudad o pedir la ubicación al usuario
    const ciudad = prompt("¿ciudad?", "Madrid")
    const url = `https://wttr.in/${ciudad}?format=%C&lang=en`; 
    // Con %C Obtiene SÓLO la condición climática
    // se modifica URL para ingles para varaible estilos en función actualizarEstilos

    try {
        const respuesta = await fetch(url);
        const condicion = await respuesta.text();
        console.log(condicion)
        actualizarEstilos(condicion);
        document.getElementById("weather").textContent = `En ${ciudad}:  ${condicion}`;
    } catch (error) {
        document.getElementById("weather").textContent = "Error al obtener el clima";
        console.error("Error en la consulta de la API:", error);
    }
}

function actualizarEstilos(condicion) {
    // const body = document.body;
    const estilos = {
        'Sunny': { background: '#ffcc00', color: '#333' }, // Soleado
        'Partly cloudy': { background: '#b0bec5', color: '#000' }, // Parcialmente nublado
        'Overcast': { background: '#78909c', color: '#fff' }, // Muy nublado
        'Light rain': { background: '#4a6572', color: '#fff' }, // Lluvia ligera
        'Heavy rain': { background: '#263238', color: '#fff' }, // Lluvia fuerte
        'Thunderstorm': { background: '#424242', color: '#fff' }, // Tormenta
        'Snow': { background: '#e0f7fa', color: '#000' }, // Nieve
        'Mist': { background: '#cfd8dc', color: '#000' } // Niebla
    };
    // Asigna valores por defecto si no hay coincidencias
    let estilo = estilos[condicion] || { background: '#90a4ae', color: '#000' }; 
    
    document.body.style.background = estilo.background;
    document.body.style.color = estilo.color;
}

obtenerClima();