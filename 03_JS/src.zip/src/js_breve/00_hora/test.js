function cambiarFondo() {
    const ahora = new Date();
    let hora = ahora.getHours();
    console.log(hora)
    // se añade este prompt para poder probar el script
    //   con distintas horas
    hora = parseInt(prompt("¿Hora?"));

    let colorFondo;
    let mensaje;

    if (hora >= 6 && hora < 12) {
        colorFondo = "#FFEEA9"; // Amarillo claro
        mensaje = "Buenos días ☀️";
        document.body.style.color = "black";
    } else if (hora >= 12 && hora < 18) {
        colorFondo = "#FFB74D"; // Naranja claro
        mensaje = "Buenas tardes 🌇";
        document.body.style.color = "black";
    } else {
        colorFondo = "#2C3E50"; // Azul oscuro
        mensaje = "Buenas noches 🌙";
        document.body.style.color = "white";
    }

    document.body.style.backgroundColor = colorFondo;
    document.getElementById("mensaje").innerText = mensaje;
}

cambiarFondo(); // Cambia el fondo al cargar la página
setInterval(cambiarFondo, 60000); // Actualiza cada minuto