// no se ejecuta hasta que termine de cargar la página
// permite añadir el fichero .js en head
window.onload = function() {
    const btn = document.getElementById("crea")
    // dos formas de asociar eventos
    // btn.addEventListener("click", creaLista);
    btn.onclick = creaLista;
    btn.addEventListener("focusout", decora);
}

function creaLista() {
  let lista = document.createElement("ul");
  for (let i = 0; i < 10; i++) {
    let li = document.createElement("li");
    li.innerHTML = i;
    lista.append(li);
  }
  const h1 = document.querySelector("h1");
  h1.after(lista);
}


function decora() {
    const h1 = document.querySelector("h1");
    h1.style.color = "blue" 
}