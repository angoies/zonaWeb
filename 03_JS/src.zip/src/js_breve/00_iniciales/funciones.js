function escribe () {
    document.write("<h2> Desde botón !! </h2>")
}