document.write("<h2>Hola Mundo </h2>");
document.write(
  "<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Similique repellendus velit aut! </p> "
);

document.write("<ul>");
for (let i = 0; i < 5; i++) {
  document.write("<li> item ", i);
}
document.write("</ul>");
