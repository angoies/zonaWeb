// Varias formas de acceder a los inputs del formulario
// a) acceder a cada input con getElementById
// b) usando el id

function checkForm1() {
  const pass1 = document.getElementById("pwd1");
  const pass2 = document.getElementById("pwd2");
  if (pass1.value != pass2.value) {
    alert("Error: clave y confirmación deben ser iguales");
    return false;
  }
  alert("Clave correcta: " + pass1.value);
  return true;
}

function checkForm2() {
  // usamos directamente los id 
  if (pwd1.value != pwd2.value) {
    alert("Error: clave y confirmación deben ser iguales");
    return false;
  }
  alert("Clave correcta: " + pwd1.value);
  return true;
}

