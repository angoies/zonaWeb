// File: dom-002-clase.js

// .getElementsByTagName()
// ejemplo acceso por etiqueta, devuelve colección de elementos
const parrafos = document.getElementsByTagName("p");
console.log("Nª de párrafos: ", parrafos.length);

// .textContent
// contar nº de letras de todos los párrafos:
let suma = 0;
for (let i = parrafos.length - 1; i >= 0; i--)
  suma += parrafos[i].textContent.length;
console.log("Total chars en párrafos: ", suma);

function amarillo() {
  // .getElementsByClassName() acceso por clase
  const externo = document.getElementsByClassName("externo");
  console.log(externo);

  // .style  acceso a propiedades CSS.
  //  Observe como se usa la propiedad background-color => backgroundColor
  // for (let i = 0; i < externo.length; i++) {
  //   externo[i].style.backgroundColor = "yellow";
  // }
  for (let ele of externo)
    ele.style.backgroundColor = "yellow";
}

function borde() {
  // .getElementById()  acceso por ID: deb devolver un único elemento
  const id = document.getElementById("content");
  id.style.border = "4px blue double";
  // se podía document.getElementById("content").style.border = "4px blue double";
}

function subraya() {
  // .querySelector() .querySelectorAll()
  //    querySelector => el primero que cumpla
  //    querySelectorAll => todos los que cumplan
  const ele = document.querySelector("#content div p");
  if (ele != null)
    ele.style.textDecoration ="underline 4px red";
}

function color() {
  const parrafos = document.querySelectorAll("#content div p");
  for (let i = parrafos.length - 1; i >= 0; i--) {
    parrafos[i].style.color = "blue";
  }
}

function porClase() {
  const parrafos = document.querySelectorAll("#content div p");
  // .className  ahora modificamos estilo de forma indirecta: 
  // añadiendo al atributo class el valor dinamico
  //  => esa clase tiene asociados small-caps);
  for (let i = parrafos.length - 1; i >= 0; i--) {
    // una forma "artesana": parrafos[i].className += " dinamico"; // += para no perder las clases previas
    parrafos[i].classList.add("dinamico");
  }
}
