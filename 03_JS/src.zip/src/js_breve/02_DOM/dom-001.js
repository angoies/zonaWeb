// file: dom-001-clase.js

// accede a propiedades de document
//  título, url, fecha última modificación..
const titulo = document.title;
const url = document.URL;
const lastModified = document.lastModified;

// las muestra en la página HTML
document.write("<hr/><h2> Generado desde Javascript</h2>")
document.write("<p> <code>document.URL</code>: ", url)
document.write("<br><code>document.title</code>: ", titulo)
document.write( "<br><code>document.lastModified</code>: ", lastModified, "</p>");
document.title ="Modificado desde dom01.js"

// // otros: document.links, retorna HTMLCollection
document.write("<p>Valor de <code>document.links.length</code>:",
                 document.links.length, "</p>");

// Genero lista con las URL de los enlaces
document.write("<ul>");
for (let i = 0; i < document.links.length; i++)
  document.write("<li>", i, ": ",  document.links[i]);

// Si no necesita el indice
for ( let enlace of document.links)
  document.write("<li>", enlace);


document.write("</ul>");



