// file: dom-004-clase.js
// Crear elementos e insertarlos, borrarlos, reemplazar

// .createElement()
//  crea dos nuevos elemento (pero no los añade..)
let p1 = document.createElement("p");
let h2 = document.createElement("h2");

// les añade contenido
p1.textContent = "(p1) Creado desde JavaScript";
p1.style.color = "blue"
h2.innerHTML = "(h2) Y este con <em>innerHTML</em>";
h2.style.color = "red"

// añadir como hijo de un contenedor append o prepend
let padre = document.querySelector("article");
padre.append(p1);

// // Nota: si el argumento hace referencia a nodo existente (NO CREADO), 
// //  lo mueve de la posición actual su nueva posición 


// // x.before(y) x.after(y)
// // Inserta y justo antes o despues de x.
let x = document.querySelector("article h2"); 
x.after(h2);


//  Crear item lista e insertarlo como tercer elemento
// var nuevo = document.createElement("li");
// nuevo.append("texto añadido a li"); // nuevo.textContent ="...."
// nuevo.style.backgroundColor ="yellow" 
// var segundo = document.querySelector("footer ol li:nth-child(2)");
// segundo.after(nuevo);

function añadir() {
    let nuevo = document.createElement("li");
    nuevo.textContent = "texto añadido a li con textContent"
    nuevo.append(" ... y texto añadido a li con append");
    nuevo.style.backgroundColor ="yellow" 
    let segundo = document.querySelector("footer ol li:nth-child(2)");
    if (segundo != null)
        segundo.after(nuevo);   
}

function borra() {
    const busca = document.querySelector("footer ol li:first-child");
    if (busca != null)
        busca.remove()
}

function reemplaza () {
    // x.replaceWith(y)  reemplaza x por el nodo y.
    let lorigen  = document.querySelector("ol li:first-child");
    let ldestino = document.querySelector("ol li:last-child");  
    lorigen.replaceWith(ldestino);
}
