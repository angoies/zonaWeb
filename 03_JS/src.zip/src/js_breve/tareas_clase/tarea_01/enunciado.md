# Tarea

Se le proporciona página HTML (ver captura 00). Incluir en el fichero `js/tarea.js` el código JavaScript  necesario para que:

1. Botón Glosario: genera un glosario con todas las abreviaturas que encuentra en el artículo, mostrando la abreviatura y su significado (atributo `title`). Ver resultado en captura 01. 
2. **Opcional**. Botón Revisa: genera una lista con las imágenes que existen mostrando el valor del atributo `src` y el valor del atributo `alt`. Si este segundo no existe muestra mensaje de error. Además le aplica estilos a las imágenes. Ver resultado en captura 02. 

