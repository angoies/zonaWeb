<?php 
   phpinfo();
?> 